Kostentracker PWA – kompakte Dashboard-Version

Enthalten:
- Kompakte Startseite mit frei verfügbarem Budget
- Wochenbudget (Montag bis Sonntag)
- Details zu Fixkosten, Versicherungen, Haushalt und noch kommenden Abbuchungen
- Neue Übersicht für Haushalt, Fixkosten, Versicherungen und separate Reisen
- Schnellaktion „Abrechnung hinzufügen“
- Einstellungen für Startgehalt und Gehaltstag
- Automatische Verschiebung des Gehaltstags auf Montag, wenn er auf Samstag/Sonntag fällt
- PWA/Offline-Unterstützung und schwarzes K/€-Icon

Installation über GitHub Pages:
1. Alle Dateien dieses Ordners in das Repository hochladen.
2. GitHub Pages für den main-Branch / (root) aktivieren.
3. URL auf dem iPhone in Safari öffnen.
4. Teilen > Zum Home-Bildschirm.

Hinweis: Finanzdaten bleiben im localStorage des jeweiligen Browsers/Geräts.
